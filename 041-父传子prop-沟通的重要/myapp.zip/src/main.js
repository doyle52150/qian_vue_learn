import { createApp } from 'vue'
// import './style.css'
import App from './04-属性透传案例/App.vue'

createApp(App).mount('#app')
