import { createApp } from 'vue'
// import './style.css'
import App from './10-订阅发布/App.vue'

var app = createApp(App)
app.mount('#app')
