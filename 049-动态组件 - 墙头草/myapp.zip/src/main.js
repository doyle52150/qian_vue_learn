import { createApp } from 'vue'
// import './style.css'
import App from './14-插槽/demo/App.vue'

var app = createApp(App)
app.mount('#app')
