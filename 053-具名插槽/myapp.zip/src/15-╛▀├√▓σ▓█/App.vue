<!--
 * @作者: kerwin
-->
<template>
    <div>
        app
        <Child>
            <template #left>
                <span><i>图标</i>-返回</span>
            </template>
            <!-- <template v-slot> -->
                <span><b>标题</b></span>
            <!-- </template> -->
            <template #right>
                <span ><i>图标</i>-首页</span>
            </template>
        </Child>

        <!-- <Swiper>
            <li>

                <img :src=""/>
            </li>
            <li>

            </li>
            <li>33333</li>
        </Swiper> -->
    </div>
</template>
<script>
import Child from './Child.vue'
export default {
    components:{
        Child
    }
}
</script>
