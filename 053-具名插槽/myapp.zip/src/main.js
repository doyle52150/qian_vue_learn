import { createApp } from 'vue'
// import './style.css'
import App from './19-生命周期-销毁/App.vue'

var app = createApp(App)
app.mount('#app')
