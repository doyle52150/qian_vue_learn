<!--
 * @作者: kerwin
-->
<template>
    <div>
        <!-- <MySwiper v-if="datalist.length" :slides-per-view="3" :space-between="50" :loop="false" @kerwinslidechange="handleChange">
            <MySwiperItem v-for="data in datalist" :key="data">
                {{ data }}
            </MySwiperItem>
        </MySwiper> -->

        <MySwiper v-if="datalist.length" :slides-per-view="3" :space-between="50" :loop="false" >
            <MySwiperItem v-for="data in datalist" :key="data.id">
                <!-- {{data.nm}} -->
                <img :src="data.img" :alt="data.nm" style="width:100%">
            </MySwiperItem>
        </MySwiper>
    </div>
</template>

<script>
import MySwiper from './MySwiper.vue';
import MySwiperItem from './MySwiperItem.vue';
import axios from 'axios'

export default {
    components: {
        MySwiper,
        MySwiperItem
    },
    data() {
        return {
            datalist: []
        }
    },
    mounted() {
        axios.get('test.json').then(res=>{
            // console.log()
            this.datalist  =res.data.data.hot
        })
    },
    methods:{
        handleChange(index){
            console.log("app-",index)
        }
    }
}
</script>

