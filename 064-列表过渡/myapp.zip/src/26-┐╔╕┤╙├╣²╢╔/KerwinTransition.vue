<template>
    <div>
        <Transition :name="myname">
            <slot></slot>
        </Transition>
    </div>
</template>

<script>
export default {
   props:["myname"]
}
</script>

<style>
.ltor-enter-active{
    animation:kerwianimate 1s;
}

.ltor-leave-active{
    animation:kerwianimate 1s reverse;
}

@keyframes kerwianimate{
    0%{
        transform: translateX(-100px);
        opacity: 0;
    }
    100%{
        transform: translateX(0);
        opacity: 1;
    }
}

.rtol-enter-active{
    animation:kerwianimate2 1s;
}

.rtol-leave-active{
    animation:kerwianimate2 1s reverse;
}

@keyframes kerwianimate2{
    0%{
        transform: translateX(100px);
        opacity: 0;
    }
    100%{
        transform: translateX(0);
        opacity: 1;
    }
}
</style>

