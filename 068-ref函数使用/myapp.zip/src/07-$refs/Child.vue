<!--
 * @作者: kerwin
-->
<template>
    <div>
        child--{{childtitle}}
    </div>
</template>
<script>
export default {
    data(){
        return {
            childtitle:"11111111"
        }
    }
}
</script>
