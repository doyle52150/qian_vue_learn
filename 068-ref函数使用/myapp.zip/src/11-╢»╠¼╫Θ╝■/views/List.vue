<!--
 * @作者: kerwin
-->
<template>
    <div>
        list
        <input />
    </div>
</template>
<script>
export default {
    name:"list"
}
</script>
