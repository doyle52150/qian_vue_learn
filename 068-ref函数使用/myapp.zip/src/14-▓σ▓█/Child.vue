<!--
 * @作者: kerwin
-->
<template>
    <div>
        <slot></slot>
        child
        <slot></slot>
    </div>
</template>
