<!--
 * @作者: kerwin
-->
<template>
    <div>
        <input type="text" v-model="mytext">
        <button @click="handleAdd">add</button>

        <!-- <ul> -->
            <TransitionGroup tag="ul" name="kerwin">
                <li v-for="(item, index) in datalist" :key="item">
                    {{ item }}

                    <button @click="handleDel(index)">del</button>
                </li>
            </TransitionGroup>
        <!-- </ul> -->
    </div>
</template>
<script>
export default {
    data() {
        return {
            mytext: "",
            datalist: ["11", "22", "33"],
        }
    },
    methods: {
        handleAdd() {
            console.log("add", this.mytext)
            this.datalist.push(this.mytext)

            //清空输入框
            this.mytext = ""
        },
        handleDel(index) {
            console.log("del", index)

            this.datalist.splice(index, 1)
        }
        // handleInput(evt){
        //     // console.log("input",evt.target.value)
        //     this.mytext = evt.target.value
        // }
    }
}
</script>
<style>
.kerwin-enter-active{
    animation:kerwianimate 1s;
}

.kerwin-leave-active{
    animation:kerwianimate 1s reverse;
}

@keyframes kerwianimate{
    0%{
        transform: translateX(100px);
        opacity: 0;
    }
    100%{
        transform: translateX(0);
        opacity: 1;
    }
}

html,body{
    overflow-x: hidden;
}

.kerwin-move{
    transition: all 1.5s ease;

} /* 对移动中的元素应用的过渡 */

/* 确保将离开的元素从布局流中删除
  以便能够正确地计算移动的动画。 */
.kerwin-leave-active {
  position: absolute;
}
</style>