<template>
    <div>
        <button @click="isShow=!isShow">click</button>
        <Transition enter-active-class="animate__animated animate__bounceIn" leave-active-class="animate__animated animate__bounceOut">
            <div v-if="isShow">11111111</div>
        </Transition>
        
    </div>
</template>

<script>
import 'animate.css'
export default {
    data(){
        return {
            isShow:true
        }
    }
}
</script>

<style>

</style>

