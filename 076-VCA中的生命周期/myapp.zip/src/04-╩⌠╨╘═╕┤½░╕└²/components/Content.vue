<!--
 * @作者: kerwin
-->
<template>
    <div>
        Content
    </div>
</template>
<style scoped>
div{
    flex:1;
}
</style>