<template>
    <div>
        <button @click="isShow=!isShow">click</button>
        <Transition name="kerwin" mode="out-in">
            <div v-if="isShow">11111111</div>
            <div v-else>222222</div>
        </Transition>
        
    </div>
</template>

<script>
export default {
    data(){
        return {
            isShow:true
        }
    }
}
</script>

<style>
.kerwin-enter-active{
    animation:kerwianimate 1s;
}

.kerwin-leave-active{
    animation:kerwianimate 1s reverse;
}

@keyframes kerwianimate{
    0%{
        transform: translateX(100px);
        opacity: 0;
    }
    100%{
        transform: translateX(0);
        opacity: 1;
    }
}
</style>

