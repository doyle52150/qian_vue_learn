import { createApp } from 'vue'
// import './style.css'
import App from './37-setup语法糖/demo/App.vue'

var app = createApp(App)
// app.component
// app.directive("kerwin",{
//     //钩子
//     mounted(el){
//         // console.log("当前节点插入到父节点得时候调用",el)
//         el.style.background='yellow'
//     }
// })
app.mount('#app')
