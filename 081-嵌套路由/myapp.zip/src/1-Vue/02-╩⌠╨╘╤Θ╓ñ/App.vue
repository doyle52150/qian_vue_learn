<!--
import NavbarVue from '../02/components/Navbar.vue';
 * @作者: kerwin
-->
<template>
    <div>
        <Navbar :my-title="title" left="返回" right="success"
        :leftshow="false" 

        ></Navbar>
    
    </div>
</template>

<script>
import Navbar from './Navbar.vue';

export default {
    data() {
        return {
            title:"首页状态",
            propobj: {
                'my-title': '电影1',
                left: '返回',
                right: '首页'
            }
        }
    },
    methods:{
        handleClick(){
            this.title="首页状态-11111"
        }
    },
    components: {
        Navbar
    }
}
</script>

