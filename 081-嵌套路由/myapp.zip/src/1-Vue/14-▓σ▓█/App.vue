<!--
 * @作者: kerwin
-->
<template>
    <div>
        app
        <Child>
            <div>我是在app组件中的一段html代码</div>
            <div>我是在app组件中的一段html代码</div>
        </Child>

        <!-- <Swiper>
            <li>

                <img :src=""/>
            </li>
            <li>

            </li>
            <li>33333</li>
        </Swiper> -->
    </div>
</template>
<script>
import Child from './Child.vue'
export default {
    components:{
        Child
    }
}
</script>
