<!--
 * @作者: kerwin
-->
<template>
    <div>
        cinemas
    </div>
</template>
