<!--
 * @作者: kerwin
-->
<template>
    <div>
        nowplaying
    </div>
</template>
