<!--
 * @作者: kerwin
-->
<template>
    <div>
        home
        <input type="text">
    </div>
</template>
<script>
export default {
    name:"home"
}
</script>
