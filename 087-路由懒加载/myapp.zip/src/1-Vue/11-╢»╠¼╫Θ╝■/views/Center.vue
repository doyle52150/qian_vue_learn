<!--
 * @作者: kerwin
-->
<template>
    <div>
        center
        <input />
    </div>
</template>

<script>
export default {
    name:"center"
}
</script>

