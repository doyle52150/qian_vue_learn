/*
 * @作者: kerwin
 */
/*
Flux 架构就像眼镜：您自会知道什么时候需要它。

1. 页面有多个需要共享的状态，引入vuex，便于维护 （非父子通信）
2. 缓存部分异步数据，减少后端服务的访问，增加用户体验
*/

import {createStore } from 'vuex'

const store = createStore({
    state(){
        return {
            isTabbarShow:true
        }
    }
})

export default store