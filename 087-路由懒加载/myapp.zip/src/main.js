import { createApp } from 'vue'
// import './style.css'
import App from './3-Vuex/App.vue'
import router from './3-Vuex/router'
import store from './3-Vuex/store'

var app = createApp(App)
// app.component
// app.directive("kerwin",{
//     //钩子
//     mounted(el){
//         // console.log("当前节点插入到父节点得时候调用",el)
//         el.style.background='yellow'
//     }
// })
 
app.use(router) //注册路由插件
app.use(store) //注册vuex插件
app.mount('#app')
