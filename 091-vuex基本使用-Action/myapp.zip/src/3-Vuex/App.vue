<template>
    <div>
        <!-- 插槽-路由容器 -->
        <router-view></router-view>
        <!-- <router-view></router-view>
        <router-view></router-view> -->

        <Tabbar v-show="isTabbarShow"></Tabbar>
    </div>
</template>

<script>

import { mapState } from 'vuex';
import Tabbar from './components/Tabbar.vue'
export default {
    components: {
        Tabbar
    },
    mounted(){
        console.log(this.$store.state.isTabbarShow)
    },
    // computed:{
    //     isTabbarShow(){
    //         return this.$store.state.isTabbarShow
    //     },

    //     aaa(){

    //     }
    // }

    computed:{
        ...mapState(['isTabbarShow']),

        // aaa(){}
    }
}
</script>
<style>
*{
    margin:0;
    padding:0;
}
ul{
    list-style: none;
}
</style>
