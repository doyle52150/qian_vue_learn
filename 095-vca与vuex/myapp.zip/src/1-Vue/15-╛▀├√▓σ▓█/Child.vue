<!--
 * @作者: kerwin
-->

<template>
    <div>
        <slot name="left"></slot>
        <slot></slot>
        <slot name="right"></slot>
    </div>
</template>
