<!--
import { mapActions } from 'vuex';
import { mapState } from 'vuex';
 * @作者: kerwin
-->
<template>
    <div>
        <select  v-model="type">
            <option :value="1">App订票</option>
            <option :value="0">前台兑换</option>
        </select>
        <ul>
            <li v-for="data in filterCinemaList(type)" :key="data.cinemaId">
                {{data.name}}
            </li>
        </ul>
    </div>
</template>
<script>
import {mapActions,mapState, mapGetters} from 'vuex'
export default {
    data(){
        return {
            type:1
        }
    },
    mounted(){
        if(this.cinemaList.length===0){
            //请求数据
            // this.$store.dispatch("getCinemaList","参数演示")
            this.getCinemaList("参数演示")
        }else{
            console.log("缓存")
        }
    },

    methods:{
        ...mapActions('CinemaModule',["getCinemaList"]),

        // handleClic
    },

    computed:{
        ...mapState('CinemaModule',["cinemaList"]),
        ...mapGetters('CinemaModule',["filterCinemaList"])
    }
    // computed:{
    //     filterCinameList(){
    //         return this.$store.state.cinemaList.filter(item=>item.eTicketFlag===this.type)
    //     }
    // }
}
</script>
<style scoped>
    li{
        padding: 10px;
    }
</style>