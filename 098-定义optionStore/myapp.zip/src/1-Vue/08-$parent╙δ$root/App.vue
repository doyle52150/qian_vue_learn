<!--
 * @作者: kerwin
-->
<template>
    <div>
        app
        <Aparent></Aparent>
    </div>
</template>

<script>
import Aparent from './Aparent.vue';


export default {
    data(){
        return {
            title:"app-1111"
        }
    },
    components:{
        Aparent
    }
}
</script>
