import { createApp } from 'vue'
// import './style.css'
import App from './4-pinia/App.vue'
import router from './4-pinia/router'
import { createPinia } from 'pinia'

var app = createApp(App)
// app.component
// app.directive("kerwin",{
//     //钩子
//     mounted(el){
//         // console.log("当前节点插入到父节点得时候调用",el)
//         el.style.background='yellow'
//     }
// })
 
app.use(router) //注册路由插件
app.use(createPinia()) //注册pinia插件
app.mount('#app')
