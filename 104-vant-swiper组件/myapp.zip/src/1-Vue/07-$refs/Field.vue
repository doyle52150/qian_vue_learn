<!--
 * @作者: kerwin
-->
<template>
    <div style="background-color: yellow;">
      
        <label>{{label}}</label>:
        <input :type="type" v-model="myvalue">
    </div>
</template>
<script>
export default {
    data(){
        return {
            myvalue:""
        }
    },
    props:{
        label:{
            type:String,
            default:""
        },
        type:{
            type:String,
            default:"text"
        }
    }
}
</script>
