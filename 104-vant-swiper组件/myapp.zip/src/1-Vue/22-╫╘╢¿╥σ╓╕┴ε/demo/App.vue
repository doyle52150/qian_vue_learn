<template>
    <div>
        <div class="swiper">
            <div class="swiper-wrapper">
                <div class="swiper-slide" v-for="(data, index) in datalist" :key="data" v-swipe="{
                    index: index,
                    length: datalist.length
                }">
                    {{ data }}
                </div>
            </div>
            <!-- 如果需要分页器 -->
            <div class="swiper-pagination"></div>

        </div>
    </div>
</template>

<script>
// import Swiper bundle with all modules installed
import Swiper from 'swiper/bundle';

// import styles bundle
import 'swiper/css/bundle';
export default {
    data() {
        return {
            datalist: []
        }
    },
    directives: {
        swipe: {
            mounted(el, binding) {
                console.log(binding.value)
                let { index, length } = binding.value
                if (index === length - 1) {
                    // console.log("最后一个节点")
                    var mySwiper = new Swiper('.swiper', {
                        loop: true, // 循环模式选项
                        // 如果需要分页器
                        pagination: {
                            el: '.swiper-pagination',
                        },
                        on: {
                            slideChange: function () {
                                console.log('改变了，activeIndex为' + this.activeIndex);
                            },
                        }
                    })
                }
            }
        },
    },
    mounted() {
        setTimeout(() => {
            this.datalist = ["aa", "bb", "cc"]
            //

        }, 2000)
    }
}
</script>
<style>
.swiper {
    width: 600px;
    height: 300px;
}
</style>