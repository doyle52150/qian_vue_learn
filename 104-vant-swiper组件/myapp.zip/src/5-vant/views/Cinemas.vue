<!--
 * @作者: kerwin
-->
<template>
    <div>
        <!-- {{store.test}} -->
        <select v-model="type">
            <option :value="1">App订票</option>
            <option :value="0">前台兑换</option>
        </select>
        <ul>
            <li v-for="data in store.filterCinemaList(type)" :key="data.cinemaId">
                {{ data.name }}
            </li>
        </ul>
    </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import useCinemaStore from '../store/cinemaStore';


const type = ref(1)
const store = useCinemaStore()
onMounted(() => {
    // console.log(store.getters['CinemaModule/filterCinemaList'])
    if (store.cinemaList.length === 0) {
        //请求数据
        store.getCinemaList()

        //隐藏代码
    } else {
        console.log("缓存")
    }
})
</script>
<style scoped>
li {
    padding: 10px;
}
</style>
