import { createApp } from 'vue'
import App from './5-vant/App.vue'
import router from './5-vant/router'
import { createPinia } from 'pinia'
// 1. 引入你需要的组件
// import { Button } from 'vant';
// 2. 引入组件样式
import 'vant/lib/index.css';

//导入配置文件
import './5-vant/util/config'
var app = createApp(App)
// app.component
// app.directive("kerwin",{
//     //钩子
//     mounted(el){
//         // console.log("当前节点插入到父节点得时候调用",el)
//         el.style.background='yellow'
//     }
// })
 
app.use(router) //注册路由插件
app.use(createPinia()) //注册pinia插件
// app.use(Button)
app.mount('#app')
