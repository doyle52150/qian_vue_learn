<!--
 * @作者: kerwin
-->
<template>
    <div>
        app
        <!-- <div v-show="isShow"></div> -->
        <div v-kerwin="'red'">1111</div>
        <div v-kerwin="'yellow'">2222</div>
        <div v-kerwin="whichColor">333</div>
    </div>
</template>

<script>

export default {
    // components
    data(){
        return {
            whichColor:'blue'
        }
    },
    //局部定义
    directives: {
        // kerwin: {
        //     //钩子
        //     mounted(el,binding) {
        //         // console.log("当前节点插入到父节点得时候调用",binding)
        //         el.style.background = binding.value
        //     },
        //     updated(el,binding) {
        //         // console.log("当前节点插入到父节点得时候调用",binding)
        //         el.style.background = binding.value
        //     }
        // }
            //简写形式
        kerwin(el,binding){
            el.style.background = binding.value
        }
    }
}
</script>

