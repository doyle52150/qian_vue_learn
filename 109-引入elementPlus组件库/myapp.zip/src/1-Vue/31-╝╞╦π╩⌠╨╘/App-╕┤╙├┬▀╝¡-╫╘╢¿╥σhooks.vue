<!--
 * @作者: kerwin
-->
<template>
    <div>
        <input type="text" v-model="mytext">

        <ul>
            <li v-for="data in computedList" :key="data">
                {{ data }}
            </li>
        </ul>
    </div>
</template>

<script>
import { reactive, ref, computed } from 'vue';
//自定义的hooks
import useSearch from './search'
export default {
    setup() {
        const datalist = ref([])

        setTimeout(() => {
            datalist.value = ["aaa", "aab", "abc", "bbc", "bcd", "aef", "bdf", "cde"]
        }, 2000)

        // const {mytext,computedList} = UseSearch(state)


        return {
            // computedList,
            // mytext
            ...useSearch(datalist)
        }
    }
}
</script>

