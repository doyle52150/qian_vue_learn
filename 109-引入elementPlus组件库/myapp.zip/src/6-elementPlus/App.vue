<template>
    <div>
        <!-- 插槽-路由容器 -->
        <router-view></router-view>
        <!-- <router-view></router-view>
        <router-view></router-view> -->

    </div>
</template>

<script setup>
</script>
<style>
*{
    margin:0;
    padding:0;
}
ul{
    list-style: none;
}
</style>
