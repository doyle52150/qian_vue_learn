/*
 * @作者: kerwin
 */
//配置路由，

import { createRouter, createWebHashHistory,createWebHistory } from 'vue-router'
import NotFound from '../views/NotFound.vue'
import AddNews from '../views/AddNews.vue'
import Home from '../views/Home.vue'
import NewsList from '../views/NewsList.vue'
const routes = [
    {
        path:"/home",
        component:Home
    },
    {
        path:"/addnews",
        component:AddNews
    },
    {
        path:"/newslist",
        component:NewsList
    },

    {
        path:"/",
        redirect:"/home"
    },
    // {   path: '/:pathMatch(.*)*', 
    {   path: '/:pathMatch(.*)*',  // /aaa /bbb /ccc  /aaa/a1/a2
        component: NotFound 
    }
]
const router = createRouter({
    // history: createWebHashHistory(), // hash  #/film #/center
    history: createWebHistory(), // 
    // history /film /center
    routes, // `routes: routes` 的缩写

})


export default router