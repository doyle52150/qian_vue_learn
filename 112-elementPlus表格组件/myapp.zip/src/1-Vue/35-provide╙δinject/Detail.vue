<!--
 * @作者: kerwin
-->
<template>
    <div>
        detail
    </div>
</template>

<script>
import { inject, onMounted } from 'vue';
export default {
    mounted(){
        //this
    }   , 

    setup(){
        const show = inject("show")
        onMounted(()=>{
            show.value = false
        })
    }
}
</script>
