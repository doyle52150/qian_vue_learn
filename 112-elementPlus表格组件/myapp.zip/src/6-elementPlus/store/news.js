/*
 * @作者: kerwin
 */
import {defineStore} from 'pinia'
import {ref} from 'vue'
//第一个参数是唯一storeId
const useNewsStore = defineStore("news",()=>{
    // ref包装定义的就是 state
    const list = ref([])

    const add = (value)=>{
        list.value.push({...value})
    }
    return {
        list,
        add
    }
})

export default useNewsStore