<template>
  <el-table :data="store.list" style="width: 100%">
    <!-- <el-table-column prop="title" label="标题" width="180" /> -->
    <el-table-column label="标题" width="180">
      <template #default="scope">
        <b style="margin-left: 10px">{{ scope.row.title }}</b>
      </template>
    </el-table-column>
    <el-table-column prop="category" label="分类" width="180" />
    <el-table-column prop="content" label="内容" />

    <el-table-column label="操作" width="180">
      <template #default="scope">
        <div>
          <el-button type="warning" round @click="handleEdit(scope.row)">编辑</el-button>
          <el-button type="danger" round>删除</el-button>
        </div>
      </template>
    </el-table-column>
  </el-table>
</template>
  
<script  setup>
import useNewsStore from '../store/news';
const store = useNewsStore()


const handleEdit = (item)=>{
  console.log(item)
}
</script>
  