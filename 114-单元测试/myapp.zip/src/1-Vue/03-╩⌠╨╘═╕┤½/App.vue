<!--
 * @作者: kerwin
-->
<template>
    <div>
        <Navbar class="navbar" id="navbarid" style="background-color: yellow;" @click="handleClick()"></Navbar>
    </div>
</template>

<script>
import Navbar from './Navbar.vue';

export default {
    data() {
        return {
            
        }
    },
    components:{
        Navbar
    },
    methods:{
        handleClick(){
            console.log("app-11111")
        }
    }
    
}
</script>

