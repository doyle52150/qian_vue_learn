<template>
    <div>
        <button @click="isShow=!isShow">click</button>
        <Transition name="kerwin">
            <div v-if="isShow">11111111</div>
        </Transition>
        
    </div>
</template>

<script>
export default {
    data(){
        return {
            isShow:true
        }
    }
}
</script>

<style>
/* 下面我们会解释这些 class 是做什么的 */
.kerwin-enter-active,
.kerwin-leave-active {
  transition: all 1s ease;
}

.kerwin-enter-from,
.kerwin-leave-to {
    transform: translateX(100px);
    opacity: 0;
}
html,body{
    overflow-x: hidden;
}
</style>

