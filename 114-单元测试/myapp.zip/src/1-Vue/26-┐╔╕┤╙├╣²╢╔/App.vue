<!--
 * @作者: kerwin
-->
<template>
    <div>
        <button @click="isShow = !isShow">click</button>
        <KerwinTransition myname="ltor">
            <div v-if="isShow">111111</div>
        </KerwinTransition>


        <KerwinTransition myname="rtol">
            <div v-if="isShow">22222</div>
        </KerwinTransition>
    </div>
</template>

<script>
import KerwinTransition from './KerwinTransition.vue'
export default {
    data() {
        return {
            isShow: true
        }
    },
    components: {
        KerwinTransition
    }
}
</script>

