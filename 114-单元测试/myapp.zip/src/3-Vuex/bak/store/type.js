/*
 * @作者: kerwin
 */
// detail页面
const CHANGE_TABBAR = "changeTabbar"


// cinme页面

export {CHANGE_TABBAR}