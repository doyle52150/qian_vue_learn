import { createApp } from 'vue'
import App from './6-elementPlus/App.vue'
import router from './6-elementPlus/router'
import { createPinia } from 'pinia'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'

var app = createApp(App)
// app.component
// app.directive("kerwin",{
//     //钩子
//     mounted(el){
//         // console.log("当前节点插入到父节点得时候调用",el)
//         el.style.background='yellow'
//     }
// })
 
app.use(router) //注册路由插件
app.use(ElementPlus)
app.use(createPinia())
app.mount('#app')
