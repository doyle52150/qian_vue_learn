import { createApp } from 'vue'
// import './style.css'
import App from './01-voa/App.vue'

createApp(App).mount('#app')
