/*
 * @作者: kerwin
 */
// console.log(11111)

// 类型系统

var myname:string = "kerwin" //显式定义类型
var myname1 = "xiaoming" //隐式推断
// myname = 100
// myna
// myname1.substring(0,1)


var myage:number = 100
var myshow:boolean = true
myshow = false

var myvalue:string|number = 100
myvalue = "kerwin"


var myany:any = "323"
myany  ={}
myany = []

export default {}
