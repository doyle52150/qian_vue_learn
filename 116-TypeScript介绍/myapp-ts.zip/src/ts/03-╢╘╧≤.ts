/*
 * @作者: kerwin
 */
interface InterObj{
    name:string,
    age:number,
    location?:string, //可选属性
    [propName:string]:any
}
var myobj:InterObj


myobj = {
    name:"kerwin",
    age:100,
    location:"dalian",
    a:1,
    b:2,
    c:[],
    d:{}
}
// console.log()
// myobj.name.toFixed()
// myobj.age
export default {}