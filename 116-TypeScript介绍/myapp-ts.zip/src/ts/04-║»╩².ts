/*
 * @作者: kerwin
 */

function test(a:number,b:number):number{
    return a+b
}
var mystring:number = test(1,2)

export default{}