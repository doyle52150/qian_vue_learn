<!--
 * @作者: kerwin
-->
<template>

    <div>
        child-{{title}}

        {{item?.name}}

        <ul>
            <li v-for="data in item?.list" :key="data">
                {{data}}
            </li>
        </ul>


        <button @click="handleClick()">子</button>
    </div>
</template>

<script lang="ts">
import type {PropType} from 'vue'
interface IProps{
    name:string,
    age:number,
    list:Array<number>
}
export default{
    props:{
        title:String, //未结合ts，
        item:Object as PropType<IProps>
    },
    methods:{
        handleClick(){
            //子传父

            this.$emit("event","aaaaa")
        }
    },
    emits:{
        event(x:string){
            return x
        }
    }
}
</script>