<template>
    <div>
        <!-- app-{{myname}} -->
        {{ computedName}}
        <div ref="mydiv">我是div</div>


        <button @click="handleAdd(1)">add</button>

        <Child title="首页" :obj="{name:'kerwin',age:100}" @event="handleEvent"></Child>
    </div>
</template>
<script setup lang="ts">
import Child from './Child.vue'
import {onMounted, reactive,ref,computed} from 'vue'
// import type {Ref} from 'vue'
// const state = reactive({
//     myname:"kerwin"
// })//隐式推导
// interface IState {
//     myname:string
// }
// const state:IState = reactive({
//     myname:"kerwin"
// })

const myname = ref("kerwin") //隐式推导

// const myname:Ref<string> = ref("kerwin")
// const myname = ref<string>("kerwin")

const mydiv = ref<HTMLDivElement>()

onMounted(()=>{
    console.log(mydiv.value?.innerHTML)
})

const computedName = computed<string>(()=>myname.value.substring(0,1).toUpperCase()+myname.value.substring(1))

const handleAdd = (index:number)=>{
    console.log(index)
}

const handleEvent = (value:string)=>{
    console.log(value)
}
</script>