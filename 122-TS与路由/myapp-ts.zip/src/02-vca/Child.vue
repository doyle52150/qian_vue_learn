<!--
 * @作者: kerwin
-->
<template>
    <div>
        child-{{props.title}}

        {{props.obj?.age}}

        <button @click="handleClick">child-click</button>
    </div>
</template>

<script setup lang="ts">
// import type {PropType} from 'vue'
interface IProps{
    name:string,
    age:number
}
// const props = defineProps({
//     title:String,
//     obj:Object as PropType<IProps> 
// })

const props = defineProps<{
    title:string,
    obj?:IProps
}>()
// const emit = defineEmits(["event"])

const emit = defineEmits<{
    (e:'event',myvalue:string):void
}>()
const handleClick = ()=>{
    emit("event","dwadw")
}
</script>