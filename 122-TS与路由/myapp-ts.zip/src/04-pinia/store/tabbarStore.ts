/*
 * @作者: kerwin
 */
import {defineStore} from 'pinia'
import {ref} from 'vue'
//第一个参数是唯一storeId
const useTabbarStore = defineStore("tabbar",()=>{
    // ref包装定义的就是 state
    const isTabbarShow = ref<boolean>(true)

    const change = (value:boolean)=>{
        isTabbarShow.value = value
    }
    return {
        isTabbarShow,
        change
    }
})

export default useTabbarStore