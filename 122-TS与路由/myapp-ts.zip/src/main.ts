import { createApp } from 'vue'
// import './style.css'
import App from './04-pinia/App.vue'
import router from './04-pinia/router'
import {createPinia} from 'pinia'
createApp(App)
.use(router)
.use(createPinia())
.mount('#app')
