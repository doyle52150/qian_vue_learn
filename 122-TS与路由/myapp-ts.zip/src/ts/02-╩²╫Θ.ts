/*
 * @作者: kerwin
 */
var mylist:string[] = ["kerwin","xiaoming"]
mylist.push("tiechui")

var mylist2:number[] = [1,2,3]
mylist2.push(100)

var mylist3:(string|number)[] = ["kerwin",100]

// mylist3.push(true)
var mylist4:any[] = ["kerwin",100,{},[]]

//第二种风格， 

var mylist5:Array<string> = ["aaa","bbb"]
var mylist6:Array<string | number> = ["aaa",1000]
var mylist7:Array<any> = ["aaa",1000]

export default {}