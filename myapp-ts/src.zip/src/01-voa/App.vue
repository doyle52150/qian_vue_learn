<!--
 * @作者: kerwin
-->
<template>
    <div>
        app-{{myname}}--{{computedName}}
        <button @click="handleClick">click</button>

        <input type="text" v-model="mytext">
        <button @click="handleAdd">add</button>

        <ul>
            <li v-for="(item,index) in list" :key="item">
            {{item}}
            <button @click="handleDel(index)">del</button>
            </li>
        </ul>


        <div ref="mydiv">测试</div>
       <input type="text" ref="myinput">

       <Child style="background:yellow;" title="首页" :item="{
            name:'kerwin',
            age:100,
            list:[1,2,3]
       }" @event="handleEvent"/>
    </div>
</template>

<script lang="ts">
import Child from './Child.vue'
interface InterState{
    myname:string,
    myage:number,
    mytext:string,
    list:Array<string>
}
export default{
    components:{
        Child
    },
    data(){
        return ({
            myname:"kerwin",
            mytext:"",
            myage:100,
            list:[]
        }) as InterState
    },
    methods:{
        handleClick(){
            // this.myname = 100
            this.myname = this.myname.substring(0,1)
            // this.myage = "dwa"
            // this.list.push("111")
            //类型断言
            console.log((this.$refs.mydiv as HTMLDivElement).innerHTML)
            console.log((this.$refs.myinput as HTMLInputElement).value)
        },
        handleAdd(){
            this.list.push(this.mytext)
        },
        handleDel(index:number){
            
            // console.log(index)
            this.list.splice(index,1)
        },

        handleEvent(data:string){
            console.log("父组件evnet",data.substring(0,1))
        }
    },
    computed:{
        computedName():string{
            return this.myname.substring(0,1).toUpperCase()+this.myname.substring(1)
        }
    }
}
</script>