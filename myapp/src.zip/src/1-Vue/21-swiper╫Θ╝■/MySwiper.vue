<!--
 * @作者: kerwin
-->
<template>
    <div class="swiper">
        <div class="swiper-wrapper">
            <slot></slot>
        </div>
        <!-- 如果需要分页器 -->
        <div class="swiper-pagination"></div>

    </div>
</template>
<script>
// import Swiper bundle with all modules installed
import Swiper from 'swiper/bundle';

// import styles bundle
import 'swiper/css/bundle';
export default {
    data() {
        return {

        }
    },
    props:{
        loop:{
            type:Boolean,
            default:true
        },
        slidesPerView:{
            type:Number,
            default:1
        },
        spaceBetween:{
            type:Number,
            default:0
        }

    },
    mounted() {

        var mySwiper = new Swiper('.swiper', {
            loop: this.loop, // 循环模式选项
            // observer: true,
            slidesPerView:this.slidesPerView,
            spaceBetween:this.spaceBetween,
            // 如果需要分页器
            pagination: {
                el: '.swiper-pagination',
            },
            on: {
                slideChange:  ()=> {
                    // console.log('改变了，activeIndex为' + this.activeIndex);

                    this.$emit("kerwinslidechange",mySwiper.activeIndex)
                },
            }
        })
    }

}
</script>
<style>
.swiper {
    width: 600px;
    height: 300px;
}
</style>