<template>
    <div>
        <!-- 插槽-路由容器 -->
        <router-view></router-view>
        <!-- <router-view></router-view>
        <router-view></router-view> -->

        <Tabbar v-show="isTabbarShow"></Tabbar>
    </div>
</template>

<script setup>
import {computed} from 'vue'
import Tabbar from './components/Tabbar.vue'
import {useStore, mapState} from 'vuex'
const store = useStore() // this.$store

const state = mapState("TabbarModule",["isTabbarShow"])
console.log(state.isTabbarShow)
state.isTabbarShow = state.isTabbarShow.bind({$store:store})
const isTabbarShow = computed(state.isTabbarShow)
</script>
<style>
*{
    margin:0;
    padding:0;
}
ul{
    list-style: none;
}
</style>
