<template>
    <el-container class="layout-container-demo" style="height: 100vh">
        <el-aside width="200px">
            <el-scrollbar>
                <el-menu :router="true" :default-active="route.fullPath">
                    <el-menu-item index="/home">
                        <el-icon>
                            <HomeFilled />
                        </el-icon> <span>首页</span>
                    </el-menu-item>
                    <el-sub-menu index="/news">
                        <template #title>
                            <el-icon>
                                <message />
                            </el-icon>新闻管理
                        </template>
                        <el-menu-item index="/news/addnews">
                            <span>创建新闻</span>
                        </el-menu-item>
                        <el-menu-item index="/news/newslist">
                            <span>新闻列表</span>
                        </el-menu-item>
                    </el-sub-menu>
                </el-menu>
            </el-scrollbar>
        </el-aside>

        <el-container>
            <el-header >
                <div>新闻管理系统</div>
                <div>欢迎kerwin回来</div>
            </el-header>

            <el-main>
                <el-scrollbar>
                   <router-view></router-view>
                </el-scrollbar>
            </el-main>
        </el-container>
    </el-container>
</template>
  
<script  setup>
import { Message,HomeFilled } from '@element-plus/icons-vue'
import {useRoute} from 'vue-router'

const route = useRoute()

</script>
  
<style >
* {
    margin: 0;
    padding: 0;
}
.el-header{
    background:lightcyan;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
</style>
  