<!--
 * @作者: kerwin
-->
<template>
    <div>
        {{props.title}}
    </div>
</template>

<script setup>

import {defineProps} from 'vue'

const props = defineProps(["title"])
</script>
